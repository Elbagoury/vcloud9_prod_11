Web Login Background
====================

Set your background picture on odoo login and signup screens.

Tested on Odoo 11.0 88ccc406035297210cadd5c6278f6f813899001e
