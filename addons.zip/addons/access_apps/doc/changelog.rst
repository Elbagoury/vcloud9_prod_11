.. _changelog:

Updates
=======

`1.2.0`
-------

- REF: rename "Show Apps Menu" to "Allow install apps"
- ADD: "Allow install apps only from settings"
- IMP: group "Show Apps Menu" and "Allow install apps only from settings" under "Apps access" security category

`1.0.1`
-------

- FIX: updates for recent odoo 9.0
- IMP: apps dashboard can be showed if user has access 'Show Apps Menu'

