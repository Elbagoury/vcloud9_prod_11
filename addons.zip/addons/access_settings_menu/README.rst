Show settings menu for non-admin
================================

Adds "Show Settings Menu" tick in user's access rights tab.

Uninstallation
--------------

After uninstallating, you need to update ``base`` module to return restriction to ``Settings`` menu back.

Tested on 10.0 1be57f2825af4f3ade20a658c6f97f6cf93cc866
