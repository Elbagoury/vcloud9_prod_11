.. _changelog:

Changelog
=========

`Version 0.1 (2018 Feb 01 16:33)`
----------------
- First release for Odoo 11 Enterprise Edition Only

