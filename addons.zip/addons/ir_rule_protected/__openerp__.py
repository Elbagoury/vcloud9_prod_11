# -*- coding: utf-8 -*-
{
    'name': 'Protect ir.rule records',
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    "category": "Access",
    "support": "apps@it-projects.info",
    'website': 'https://twitter.com/yelizariev',
    "license": "LGPL-3",
    'depends': [],
    'data': [
        'views.xml',
    ],
    'installable': True
}
