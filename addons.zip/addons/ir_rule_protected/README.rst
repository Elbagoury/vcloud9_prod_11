Protect ir.rule records
=======================

The module allows protect ir.rule from modifying and deleting. Once a rule is marked as protected only superuser is able to control this rule.

Also, the module protect itself from uninstalling by non-superuser.

Tested on 10.0 1be57f2825af4f3ade20a658c6f97f6cf93cc866
