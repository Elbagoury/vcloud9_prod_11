====================
 Backend debranding
====================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Configuration
=============

Does not require pre-configuration

Usage
=====
* Open menu ``Settings >> Parameters >> System Parameters``
* Modify selected parameters
